#nombre en lettre (1-999)
nom= {1: "un", 2: "deux", 3: "trois", 4: "quatre",5:"cinq",6:"six",7:"sept",8:"huit",9:"neuf",
     10:"dix",11:"onze",12:"douze",13:"treize",14:"quatorze",15:"quinze",16:"seixe",17:"dix sept",18:"dix huit",19:"dix neuf",
     20:"vingt",30:"trente",40:"quarante",50:"cinquante",60:"soixante",70:"soixante dix",80:"quatre vingt dix",90:"quatre vingt dix",
     100:"cent", 200:"deux cent",300:"trois cent",400:"quatre cent",
     500:"cinq cent",600:"six cent",700:"sept cent",800:"huit cent",900:"neuf cent"}
nbre = int(input("entrer le nombre a lire : "))

if nbre <= 999:
    if nbre in nom:
        k=nom.get(nbre)
        print(k)


    else:
        b=nbre%10
        b=nom.get(b)
        c=nbre//10
        c=c*10
        c=nom.get(c)
        result=c + b
        print(result)

else:
    print("erreur! entrer un nombre a 4 chiffre")