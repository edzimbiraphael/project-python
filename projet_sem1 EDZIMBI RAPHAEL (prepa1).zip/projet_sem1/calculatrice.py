while True:
    print("************************************************")

    print("*         MENU DES OPERATIONS                       *")

    print("************************************************")

    print("***1. ADDITION")
    print("***2. SOUSTRACTION")
    print("***3. MULTIPLICATION")
    print("***4. DIVISION")
    print("***5. QUITTER LE PROGRAMME")
    operation = int(input("Quel operation souhatez-vous effectuer? : "))
    if operation == 5:
        break
    a = int(input("entrer le premier entier : "))
    b = int(input("entrer le second entier : "))
    if operation == 1:
        print(a, "+", b, "=", a + b)
    elif operation == 2:
        print(a, "-", b, "=", a - b)
    elif operation == 3:
        print(a, "*", b, "=", a * b)
    elif operation == 4:
        if b == 0:
            print("entrer un diviseur different de 0")
        else:
            op = input('choissisez un operateur % ou / ? :')
            if op == "%":
                print(a, "%", b, "=", a % b)
            elif op == "/":
                print(a, "/", b, "=", a / b)
